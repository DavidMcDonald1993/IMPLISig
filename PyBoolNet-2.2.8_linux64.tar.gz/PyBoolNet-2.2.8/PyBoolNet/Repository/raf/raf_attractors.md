

### Attractor Report
 * created on 12. Jun. 2017 using PyBoolNet, see https://github.com/hklarner/PyBoolNet

### Steady States
| steady state |
| ------------ | 
| 001          |

### Asynchronous STG
 * completeness: True

| trapspace      | univocal  | faithful  |
| -------------- | --------- | --------- |
| 11-            | True      | True      |

### Synchronous STG
 * completeness: True

| trapspace      | univocal  | faithful  |
| -------------- | --------- | --------- |
| 11-            | True      | True      |

### Network
| Erk     | Raf&Mek | Mek&Erk |
| ------- | ----------------- |
| Mek     | Raf&Mek | Erk     |
| Raf     | !Raf | !Erk       |

