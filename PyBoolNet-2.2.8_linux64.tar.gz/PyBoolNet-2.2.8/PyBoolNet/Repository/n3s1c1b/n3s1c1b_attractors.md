

### Attractor Report
 * created on 12. Jun. 2017 using PyBoolNet, see https://github.com/hklarner/PyBoolNet

### Steady States
| steady state |
| ------------ | 
| 111          |

### Asynchronous STG
 * completeness: True

| trapspace      | univocal  | faithful  |
| -------------- | --------- | --------- |
| -00            | True      | True      |

### Synchronous STG
 * completeness: True

| trapspace      | univocal  | faithful  |
| -------------- | --------- | --------- |
| -00            | True      | True      |

### Network
| v4      | v5&v6 | !v4 |
| ------- | ----------- |
| v5      | v6          |
| v6      | v6 | v5     |

